### Đề bài

- Tên file: `Home.aspx`
- Hiện bảng Imployee với 3 cột: Master ID, Master Name Select
- Khi mà click vào vào một hàng thì chuyển sang trang mới để edit
- Khi nhấn Save, sẽ lưu vào database và chuyển sang trang Chủ