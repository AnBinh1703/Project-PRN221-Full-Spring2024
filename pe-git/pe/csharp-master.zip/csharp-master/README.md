# CSHARP- PRN292 |
All source for .NET and C# includes:
- **IN CLASS**: All source in my class.
- **KEY PE**: code that I prepared to take prn292 practice exam. All projects I use `DataProvider` I write to use, look at **PE SAMPLE** lessons to understand how to use.
- **PRACTIVE**: code practice.
- **PE SAMPLE**: practice exam in FPT university.

