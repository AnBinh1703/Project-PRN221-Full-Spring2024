﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class Triangle
    {
        // The overloaded Draw() method. (nạp chồng)
        //public void Draw(int x, int y, int height, int width) {...}
        //public void Draw(float x, float y, float height, float width) {...}
        //public void Draw(Point upperLeft, Point bottomRight) {...}
        //public void Draw(Rect r) {...}
    }
}
