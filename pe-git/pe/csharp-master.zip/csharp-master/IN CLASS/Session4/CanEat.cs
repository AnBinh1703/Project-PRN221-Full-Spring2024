﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{
    // Interface này định nghĩa thứ có khả năng biết ăn. 
    public interface CanEat
    {

        void Eat();
    }
}
