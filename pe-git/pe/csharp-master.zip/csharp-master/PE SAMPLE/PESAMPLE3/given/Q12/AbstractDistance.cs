﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OOPReview
{
    public abstract class AbstractDistance
    {
        public abstract double GetDistance(Point p1, Point p2);
    }
}
