﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q12
{
    class Summer : ISeason
    {
        public void say()
        {
            Console.WriteLine("Sumer perfumes usually are citrus based scents that cool the skin");
        }
    }
}
