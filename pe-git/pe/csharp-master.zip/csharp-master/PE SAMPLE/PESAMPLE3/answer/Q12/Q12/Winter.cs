﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Q12
{
    class Winter : ISeason
    {
        public void say()
        {
            Console.WriteLine("Winter is the coldest season of the year in polar and temperate zones");
        }
    }
}
