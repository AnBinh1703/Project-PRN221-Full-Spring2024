using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EvoltingStore.Pages
{
    public class SignupModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
