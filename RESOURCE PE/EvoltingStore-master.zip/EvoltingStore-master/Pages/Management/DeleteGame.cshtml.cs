using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EvoltingStore.Pages.Management
{
    public class DeleteGameModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
