﻿namespace EvoltingStore.Entity
{
    public class News
    {
        public String Title { get; set; }
        public String Date { get; set; }
        public String Description { get; set; }
        public String Link { get; set; }
        public String Image { get; set; }
    }
}
