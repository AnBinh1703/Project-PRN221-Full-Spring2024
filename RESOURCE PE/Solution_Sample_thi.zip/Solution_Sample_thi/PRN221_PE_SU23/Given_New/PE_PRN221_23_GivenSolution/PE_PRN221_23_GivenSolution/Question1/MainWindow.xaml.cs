﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Question1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<employees> Employeess = new List<employees>();
        public employees emps = new employees();
        string oldPath = "";
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Employeess.Clear();
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;

            bool? result = openFileDialog.ShowDialog();
            try
            {
                List<employees> list = ReadDataFromFile<List<employees>>(openFileDialog.FileName);
                foreach (employees item in list)
                {
                    Employeess.Add(item);
                }
                lvEmps.ItemsSource = Employeess.ToList();
                txtOpenFile.Text = openFileDialog.FileName;
                oldPath = openFileDialog.FileName;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private T ReadDataFromFile<T>(string path)
        {
            string json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<T>(json);
        }

        private void lvEmps_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            employees emp = (employees)lvEmps.SelectedItem;
            emps = emp;
            if (emp == null)
                return;
            else
            {
                txtId.Text = emp.Id.ToString();
                txtName.Text = emp.Name.ToString();
                txtDob.Text = emp.Dob.ToString();
                txtGender.IsChecked = true;
                if (emp.IsMale == false)
                {
                    txtGender.IsChecked = false;
                }
            }
            
        }
        

        private void txtId_LostFocus(object sender, RoutedEventArgs e)
        {
            int id = int.Parse(txtId.Text);
            string name = txtName.Text;
            DateTime dob = DateTime.Parse(txtDob.Text);
            bool ismale = (bool) txtGender.IsChecked;
            foreach(employees emppp in Employeess)
            {
                if (emppp.Id == emps.Id && emppp.Name.Equals(emps.Name)
                    &&emppp.IsMale == emps.IsMale)
                {
                    emppp.Id = id;
                    emppp.Name = name;
                    emppp.Dob = dob;
                    emppp.IsMale = ismale;
                }
            }
            lvEmps.ItemsSource = Employeess.ToList();

        }

        
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
            File.WriteAllText(oldPath, JsonSerializer.Serialize(Employeess));
            MessageBox.Show("Replace File successful");
        }
    }
}
