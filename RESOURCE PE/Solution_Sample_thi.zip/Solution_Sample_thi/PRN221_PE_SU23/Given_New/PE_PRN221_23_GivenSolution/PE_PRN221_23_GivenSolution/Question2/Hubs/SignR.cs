﻿using Microsoft.AspNetCore.SignalR;

namespace Question2.Hubs
{
    public class SignR:Hub
    {
    }
}
