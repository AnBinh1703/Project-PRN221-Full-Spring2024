using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Question2.Models;

namespace Question2.Pages.Products
{
    public class ListModel : PageModel
    {
        private readonly PE_PRN_23SumContext _context;
        public ListModel(PE_PRN_23SumContext context)
        {
            _context = context;
        }

        public List<Models.Category> categorys { get; set; }
        public List<Models.Product> products { get; set; }
        public void OnGet()
        {
            categorys = _context.Categories.ToList();
            products = _context.Products
                .Include(p => p.Category)
                .ToList();
        }
    }
}
