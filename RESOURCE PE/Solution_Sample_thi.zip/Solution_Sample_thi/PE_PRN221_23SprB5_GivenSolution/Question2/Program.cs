using Microsoft.EntityFrameworkCore;
using Question2.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();
builder.Services.AddDbContext<PE_PRN_Spr23_B5Context>(option =>
option.UseSqlServer(builder.Configuration.GetConnectionString("MyDB")));
builder.Services.AddScoped<PE_PRN_Spr23_B5Context>();
var app = builder.Build();


app.MapRazorPages();
app.Run();
