﻿using System;
using System.Collections.Generic;

namespace Question2.Models
{
    public partial class Major
    {
        public string? MajorCode { get; set; }
        public string? MajorName { get; set; }
    }
}
