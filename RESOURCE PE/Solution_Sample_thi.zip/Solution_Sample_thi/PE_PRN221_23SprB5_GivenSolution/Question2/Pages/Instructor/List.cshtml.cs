using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Question2.Models;

namespace Question2.Pages.Instructor
{
    public class ListModel : PageModel
    {
        private readonly PE_PRN_Spr23_B5Context _context;
        public ListModel(PE_PRN_Spr23_B5Context context)
        {
            _context = context;
        }

        public List<Models.Instructor> instructors { get; set; }
        public void OnGet()
        {
            instructors = _context.Instructors.ToList();
        }
    }
}
