﻿using System;
using System.Collections.Generic;

namespace lab3SignalR.Model.Entities
{
    public partial class GroupChat
    {
        public GroupChat()
        {
            GroupDetails = new HashSet<GroupDetail>();
            MessageGroups = new HashSet<MessageGroup>();
        }

        public int GroupId { get; set; }
        public string GroupName { get; set; } = null!;

        public virtual ICollection<GroupDetail> GroupDetails { get; set; }
        public virtual ICollection<MessageGroup> MessageGroups { get; set; }
    }
}
