﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace lab3SignalR.Model.Entities
{
    public partial class signalRDatabaseContext : DbContext
    {
        public signalRDatabaseContext()
        {
        }

        public signalRDatabaseContext(DbContextOptions<signalRDatabaseContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Account> Accounts { get; set; } = null!;
        public virtual DbSet<GroupChat> GroupChats { get; set; } = null!;
        public virtual DbSet<GroupDetail> GroupDetails { get; set; } = null!;
        public virtual DbSet<MessageGroup> MessageGroups { get; set; } = null!;
        public virtual DbSet<MessageToUser> MessageToUsers { get; set; } = null!;

//        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
//                optionsBuilder.UseSqlServer("Data Source=();Initial Catalog=signalRDatabase;User ID=sa;Password=123456");
//            }
//        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>(entity =>
            {
                entity.ToTable("account");

                entity.Property(e => e.AccountId).HasColumnName("accountId");

                entity.Property(e => e.Username)
                    .HasMaxLength(50)
                    .HasColumnName("username");
            });

            modelBuilder.Entity<GroupChat>(entity =>
            {
                entity.HasKey(e => e.GroupId)
                    .HasName("PK__groupCha__88C1034D9A890246");

                entity.ToTable("groupChat");

                entity.Property(e => e.GroupId).HasColumnName("groupId");

                entity.Property(e => e.GroupName)
                    .HasMaxLength(50)
                    .HasColumnName("groupName");
            });

            modelBuilder.Entity<GroupDetail>(entity =>
            {
                entity.HasKey(e => e.GroupDetailsId)
                    .HasName("PK__groupDet__8D7E8FEF3BD4BBF7");

                entity.ToTable("groupDetails");

                entity.Property(e => e.GroupDetailsId).HasColumnName("groupDetailsID");

                entity.Property(e => e.AccountId).HasColumnName("accountId");

                entity.Property(e => e.GroupId).HasColumnName("groupId");

                entity.Property(e => e.GroupName)
                    .HasMaxLength(50)
                    .HasColumnName("groupName");

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.GroupDetails)
                    .HasForeignKey(d => d.AccountId)
                    .HasConstraintName("FK__groupDeta__accou__3C69FB99");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.GroupDetails)
                    .HasForeignKey(d => d.GroupId)
                    .HasConstraintName("FK__groupDeta__group__3B75D760");
            });

            modelBuilder.Entity<MessageGroup>(entity =>
            {
                entity.ToTable("messageGroup");

                entity.Property(e => e.MessageGroupId).HasColumnName("messageGroupId");

                entity.Property(e => e.AccountId).HasColumnName("accountId");

                entity.Property(e => e.GroupId).HasColumnName("groupId");

                entity.Property(e => e.MessageDetails).HasColumnName("messageDetails");

                entity.Property(e => e.TimeSend)
                    .HasColumnType("datetime")
                    .HasColumnName("timeSend");

                entity.Property(e => e.UserFrom)
                    .HasMaxLength(50)
                    .HasColumnName("userFrom");

                entity.HasOne(d => d.Account)
                    .WithMany(p => p.MessageGroups)
                    .HasForeignKey(d => d.AccountId)
                    .HasConstraintName("FK__messageGr__accou__4BAC3F29");

                entity.HasOne(d => d.Group)
                    .WithMany(p => p.MessageGroups)
                    .HasForeignKey(d => d.GroupId)
                    .HasConstraintName("FK__messageGr__group__4AB81AF0");
            });

            modelBuilder.Entity<MessageToUser>(entity =>
            {
                entity.HasKey(e => e.MessageId)
                    .HasName("PK__messageT__4808B873D3F9DB6A");

                entity.ToTable("messageToUser");

                entity.Property(e => e.MessageId).HasColumnName("messageID");

                entity.Property(e => e.MessageDetails).HasColumnName("messageDetails");

                entity.Property(e => e.TimeSend)
                    .HasColumnType("datetime")
                    .HasColumnName("timeSend");

                entity.Property(e => e.UserFrom)
                    .HasMaxLength(50)
                    .HasColumnName("userFrom");

                entity.Property(e => e.UserFromId).HasColumnName("userFromID");

                entity.Property(e => e.UserToId).HasColumnName("userToID");

                entity.HasOne(d => d.UserFromNavigation)
                    .WithMany(p => p.MessageToUserUserFromNavigations)
                    .HasForeignKey(d => d.UserFromId)
                    .HasConstraintName("FK__messageTo__userF__46E78A0C");

                entity.HasOne(d => d.UserTo)
                    .WithMany(p => p.MessageToUserUserTos)
                    .HasForeignKey(d => d.UserToId)
                    .HasConstraintName("FK__messageTo__userT__47DBAE45");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
