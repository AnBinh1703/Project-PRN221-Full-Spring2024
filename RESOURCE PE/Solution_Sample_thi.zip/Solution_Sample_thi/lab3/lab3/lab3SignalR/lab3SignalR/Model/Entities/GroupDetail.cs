﻿using System;
using System.Collections.Generic;

namespace lab3SignalR.Model.Entities
{
    public partial class GroupDetail
    {
        public int GroupDetailsId { get; set; }
        public int? GroupId { get; set; }
        public string GroupName { get; set; } = null!;
        public int? AccountId { get; set; }

        public virtual Account? Account { get; set; }
        public virtual GroupChat? Group { get; set; }
    }
}
