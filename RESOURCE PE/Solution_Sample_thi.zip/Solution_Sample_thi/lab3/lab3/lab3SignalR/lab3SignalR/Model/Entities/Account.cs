﻿using System;
using System.Collections.Generic;

namespace lab3SignalR.Model.Entities
{
    public partial class Account
    {
        public Account()
        {
            GroupDetails = new HashSet<GroupDetail>();
            MessageGroups = new HashSet<MessageGroup>();
            MessageToUserUserFromNavigations = new HashSet<MessageToUser>();
            MessageToUserUserTos = new HashSet<MessageToUser>();
        }

        public int AccountId { get; set; }
        public string Username { get; set; } = null!;

        public virtual ICollection<GroupDetail> GroupDetails { get; set; }
        public virtual ICollection<MessageGroup> MessageGroups { get; set; }
        public virtual ICollection<MessageToUser> MessageToUserUserFromNavigations { get; set; }
        public virtual ICollection<MessageToUser> MessageToUserUserTos { get; set; }
    }
}
