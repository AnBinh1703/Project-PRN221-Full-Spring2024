﻿using System;
using System.Collections.Generic;

namespace lab3SignalR.Model.Entities
{
    public partial class MessageGroup
    {
        public int MessageGroupId { get; set; }
        public int? GroupId { get; set; }
        public int? AccountId { get; set; }
        public string? MessageDetails { get; set; }
        public DateTime TimeSend { get; set; }
        public string UserFrom { get; set; } = null!;

        public virtual Account? Account { get; set; }
        public virtual GroupChat? Group { get; set; }
    }
}
