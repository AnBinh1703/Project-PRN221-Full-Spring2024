﻿using System;
using System.Collections.Generic;

namespace lab3SignalR.Model.Entities
{
    public partial class MessageToUser
    {
        public int MessageId { get; set; }
        public int? UserFromId { get; set; }
        public int? UserToId { get; set; }
        public string? MessageDetails { get; set; }
        public DateTime TimeSend { get; set; }
        public string UserFrom { get; set; } = null!;

        public virtual Account? UserFromNavigation { get; set; }
        public virtual Account? UserTo { get; set; }
    }
}
