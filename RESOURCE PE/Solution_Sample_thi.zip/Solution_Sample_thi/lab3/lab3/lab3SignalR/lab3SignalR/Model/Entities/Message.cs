﻿using System;
using System.Collections.Generic;

namespace lab3SignalR.Model.Entities
{
    public partial class Message
    {
        public int? AccountId { get; set; }
        public int AccountIdRecieve { get; set; }
        public string Message1 { get; set; } = null!;

        public virtual Account? Account { get; set; }
    }
}
