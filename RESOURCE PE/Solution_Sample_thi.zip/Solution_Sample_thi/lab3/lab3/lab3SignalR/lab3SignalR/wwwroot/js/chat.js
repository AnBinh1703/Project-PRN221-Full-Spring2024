﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();
var userId = "";
const joinGroupButton = document.getElementById("joinGroupButton");
const sendMessageGroupButton = document.getElementById("sendMessageGroupButton");
const leaveGroupButton = document.getElementById("leaveGroupButton");
const logOutButton = document.getElementById("logoutButton");
let groupName;

const loadMessage = document.getElementById("loadMessage");

///////////////// Load Message///////////////////
//    List Message Group    //
connection.on("ReceiveListMessage", function (jsonString) {
    // Giải mã chuỗi JSON thành một đối tượng JavaScript
    var messageList = JSON.parse(jsonString);
    // Hiển thị danh sách tin nhắn
   
    messageList.forEach(function (message) {
        var li = document.createElement("li");
        li.innerHTML = message.MessageDetails + " (" + new Date(message.TimeSend).toLocaleString() + ")" + " from user: " + message.UserFrom;
        document.getElementById("GroupmessagesList").appendChild(li);
    });
    
});


//   List Message To User ///
connection.on("ReceiveListMessageToUser", function (jsonString) {
    // Giải mã chuỗi JSON thành một đối tượng JavaScript
    var messageList = JSON.parse(jsonString);
    // Hiển thị danh sách tin nhắn

    messageList.forEach(function (message) {
        var li = document.createElement("li");
        li.innerHTML = message.MessageDetails + " (" + new Date(message.TimeSend).toLocaleString() + ")" + " from user: " + message.UserFrom;
        document.getElementById("messagesList").appendChild(li);
    });

});
///////////////// End Load Message///////////////////


//////////////// Join Group  //////////////////
joinGroupButton.addEventListener("click", () => {
    var list = document.getElementById('GroupmessagesList'); // select the unordered list element
    while (list.hasChildNodes()) {  // remove all child nodes until there are none left
        list.removeChild(list.firstChild);
    }
    groupName = document.getElementById("groupName").value;
    var connectId = userId;
    var username = document.getElementById("userInput").value;
    connection.invoke("JoinGroup", groupName,connectId,username);
});
//////////////// End Join Group  //////////////////

//////////////// get group name//////////////////
connection.on("ReceiveGroup", function (groupName) {
    var group = groupName;
    document.getElementById('groupName').setAttribute('readonly',true);
    document.getElementById("userGroup").value=group;
});
//////////////// end group name //////////////////




///////////////////  Leave Group    ///////////////////////////////
leaveGroupButton.addEventListener("click", () => {
    var username = document.getElementById("username").value;
    connection.invoke("LeaveGroup", groupName, username);
    document.getElementById("userGroup").value = "";
    document.getElementById("groupName").value = "";
    document.getElementById('groupName').removeAttribute('readonly');
});



//////////////////////  End Leave Group          ////////////////////////////





///////////////  Send mess to group     ///////////////////
sendMessageGroupButton.addEventListener("click", () => {
    const message = messageInput.value; 
    var groupname = document.getElementById("userGroup").value;
    var username = document.getElementById("userInput").value;
    connection.invoke("SendMessageGroup", groupname, message, userId, username);
    messageInput.value = "";
});

/////////////   End Send mess to group   ///////////////

//////////////// get message Group //////////////////
connection.on("ReceiveMessageGroup", function (user, message) {
    var msg = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    var encodedMsg = user + " says " + msg;
    var li = document.createElement("li");
    li.textContent = encodedMsg;
    document.getElementById("GroupmessagesList").appendChild(li);
});
//////////////// end get message Group  //////////////////



//////////////// Login  //////////////////
document.getElementById("loginButton").addEventListener("click", function (event) {
    var list = document.getElementById('messagesList'); // select the unordered list element
    while (list.hasChildNodes()) {  // remove all child nodes until there are none left
        list.removeChild(list.firstChild);
    }

    var userID = userId;
    var username = document.getElementById("username").value;
    document.getElementById("logoutButton").disabled = false;
    connection.invoke("getID", userID, username).catch(function (err) {
        return console.error(err.toString());
    });
 
    event.preventDefault();
});
//////////////// End Login



//////////////// LogOut //////////////////

logOutButton.addEventListener("click", function (event) {
    var userid = userId;
    var username = document.getElementById("userInput").value;

    connection.invoke("logOutUsername", userid, username).catch(function (err) {
        return console.error(err.toString());
    });

    event.preventDefault();
    connection.on("logOutUser", function (username) {
        if (username) {
            
            document.getElementById('username').removeAttribute('readonly');
            document.getElementById('username').value = "";  
            document.getElementById('groupName').removeAttribute('readonly');
            document.getElementById("loginButton").disabled = false;
            document.getElementById("joinGroupButton").disabled = true;
            document.getElementById("leaveGroupButton").disabled = true;
            document.getElementById("logoutButton").disabled = true;
            document.getElementById("userInput").value = "";
            document.getElementById("groupName").value = "";
            document.getElementById("userGroup").value = "";
        
        }
    });
});


//////////////// End LogOut  //////////////////



//////////////// Register  //////////////////
document.getElementById("registerButton").addEventListener("click", function (event) {
    var username = document.getElementById("usernameRegister").value;
    connection.invoke("registerUser", username).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
});

//////////////// End Register  //////////////////


//////////////// get User  //////////////////
connection.on("ReceiveUser", function (username, jsonString) {
    var username = username; 
    document.getElementById('username').setAttribute('readonly', true);
    document.getElementById('groupName').removeAttribute('readonly');
    document.getElementById("loginButton").disabled = true;
    document.getElementById("joinGroupButton").disabled = false;
    document.getElementById("leaveGroupButton").disabled = false;
    document.getElementById("userInput").value = username;

});
//////////////// end User//////////////////





//Disable send button until connection is established
document.getElementById("sendButton").disabled = true;


//////////////// get message//////////////////
connection.on("ReceiveMessage", function (user, message) {
    var msg = message.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    var encodedMsg = user + " says " + msg;
    var li = document.createElement("li");
    li.textContent = encodedMsg;
    document.getElementById("messagesList").appendChild(li);
});
//////////////// end get message //////////////////


//////////////// get connect ID //////////////////
connection.start().then(function () {
    connection.invoke("GetConnectionId").then(function (id) {
        document.getElementById("connectionId").innerText = id;
        userId = id;
    });
    document.getElementById("sendButton").disabled = false;
}).catch(function (err) {
    return console.error(err.toString());
});
//////////////// end get connect ID  //////////////////



//////////////// send ALL  //////////////////
document.getElementById("sendButton").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var message = document.getElementById("messageInput").value;
    connection.invoke("SendMessage", user, message).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
});
//////////////// end send ALL  //////////////////



////////////////  send to user  //////////////////
document.getElementById("sendToUser").addEventListener("click", function (event) {
    var user = document.getElementById("userInput").value;
    var receiver = document.getElementById("receiverId").value;
    var message = document.getElementById("messageInput").value;
    connection.invoke("SendToUser", user, receiver, message).catch(function (err) {
        return console.error(err.toString());
    });
    event.preventDefault();
});
//////////////// end to user  //////////////////