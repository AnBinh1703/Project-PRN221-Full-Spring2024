﻿using lab3SignalR.Model.Entities;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace SignalRChat.Hubs
{
    public class ChatHub : Hub
    {
        public static Dictionary<string, string> listUser = new Dictionary<string, string>();

        private readonly signalRDatabaseContext _db;
        public ChatHub(signalRDatabaseContext db)
        {
            _db = db;
        }
        public IEnumerable<Account> accounts { get; set; }
        public Account acc { get; set; }
        public MessageToUser mess { get; set; }
        Account accFrom { get; set; }
        Account accTo { get; set; }
        public async Task registerUser(string username)
        {
            accounts = new List<Account>();
            accounts = _db.Accounts;

            bool check = false;
            foreach (var account in accounts)
            {
                if (account.Username.Equals(username))
                {
                    check = true;
                }

            }
            if (check == true)
            {
                Console.WriteLine("username is exist ");
            }
            else
            {
                if (username.Length > 0)
                {
                    acc = new Account();
                    acc.Username = username;
                    await _db.Accounts.AddAsync(acc);
                    await _db.SaveChangesAsync();
                    Console.WriteLine("register success ");
                }
                else
                {
                    Console.WriteLine("username is empty ");

                }

            }


        }

        public IEnumerable<GroupChat> groupChat { get; set; }
        public IEnumerable<MessageGroup> messageGroups { get; set; }
        public IEnumerable<MessageToUser> messageToUser { get; set; }
        public IEnumerable<GroupDetail> groupDetails { get; set; }
        public async Task JoinGroup(string groupName, string connectID, string username)
        {
            LoadMessageGroup(groupName, connectID);
            //list all group
            groupChat = _db.GroupChats;

            //member in group
            groupDetails = _db.GroupDetails;
            //await Groups.AddToGroupAsync(Context.ConnectionId, groupName);
            await Groups.AddToGroupAsync(connectID, groupName);
            await Clients.Client(connectID).SendAsync("ReceiveGroup", groupName);

            Console.WriteLine("join success user:" + username + " id: " + connectID + " group: " + groupName);
            bool checkGroupExist = false;
            bool checkMemberInGroupExist = false;

            foreach (var group in groupChat)
            {
                if (group.GroupName.Equals(groupName))
                {
                    checkGroupExist = true;

                }

            }
            Account ac = new Account();
            ac = (from user in _db.Accounts
                  where user.Username.Equals(username)
                  select user).Single();


            int accountID = ac.AccountId;

            foreach (var group in groupDetails)
            {
                if (group.GroupName.Equals(groupName) && accountID == group.AccountId)
                {
                    checkMemberInGroupExist = true;

                }

            }
            GroupChat gr = new GroupChat();
            if (checkGroupExist == false)
            {

                gr.GroupName = groupName;
                _db.GroupChats.Add(gr);
                _db.SaveChanges();

            }
            if (checkMemberInGroupExist == false)
            {
                gr = (from g in _db.GroupChats
                      where g.GroupName.Equals(groupName)
                      select g
                    ).Single();
                GroupDetail groupDetails = new GroupDetail();
                groupDetails.GroupId = gr.GroupId;
                groupDetails.GroupName = gr.GroupName;
                groupDetails.AccountId = accountID;
                _db.GroupDetails.Add(groupDetails);
                _db.SaveChanges();

            }



        }

        public async Task SendMessageGroup(string groupName, string message, string userID, string username)
        {

            if (message.Length > 0)
            {
                await Clients.Group(groupName).SendAsync("ReceiveMessageGroup", username, message);
            }

            Console.WriteLine("get message from user: " + username + " message: " + message);

            Account ac = await _db.Accounts.FirstOrDefaultAsync(user => user.Username.Equals(username));
            GroupChat grChat = await _db.GroupChats.FirstOrDefaultAsync(gr => gr.GroupName.Equals(groupName));
            if (ac == null || grChat == null || message.Length <= 0)
            {
                return;
            }

            int accountID = ac.AccountId;
            int groupID = grChat.GroupId;

            MessageGroup messageGroup = new MessageGroup();
            messageGroup.AccountId = accountID;
            messageGroup.GroupId = groupID;
            messageGroup.MessageDetails = message;
            messageGroup.TimeSend = DateTime.Now;
            messageGroup.UserFrom = username;
            await  _db.MessageGroups.AddAsync(messageGroup);
            await _db.SaveChangesAsync();
        }

        public async Task LeaveGroup(string groupName, string username)
        {
            // Load GroupDetails into a list
            groupDetails = _db.GroupDetails;

            Account ac = await _db.Accounts.FirstOrDefaultAsync(user => user.Username.Equals(username));
            if (ac == null)
            {
                return;
            }

            int accountID = ac.AccountId;

            await Groups.RemoveFromGroupAsync(Context.ConnectionId, groupName);
            await Clients.Client(Context.ConnectionId).SendAsync("UserLeft", username);
            Console.WriteLine("user: " + username + " has left group: " + groupName);

            // Remove associated GroupDetails from the database
            foreach (var group in groupDetails)
            {
                if (group.AccountId == accountID)
                {
                    _db.GroupDetails.Remove(group);
                }
            }

            // Save changes to the database
            await _db.SaveChangesAsync();
        }

        public async Task getID(string userID, string username)
        {
            accounts = new List<Account>();
            accounts = _db.Accounts;
            LoadMessageUser(username, userID);
            bool check = false;
            bool checkDB = false;
            foreach (var item in accounts)
            {
                if (item.Username.Equals(username))
                {
                    checkDB = true;

                }

            }


            if (checkDB == true)
            {
                foreach (var item in listUser)
                {
                    if (item.Value.Equals(username))
                    {
                        check = true;

                    }
                    if (item.Key.Equals(userID))
                    {
                        check = true;

                    }

                }



                if (check != true)
                {
                    listUser.Add(userID, username);
                    Console.WriteLine("username is: " + username + " userId: " + userID);

                    await Clients.Client(userID).SendAsync("ReceiveUser", username);

                }
                else
                {
                    Console.WriteLine("username is exist ");
                }
            }
            else
            {
                Console.WriteLine("username not exist in data");
            }


        }


        public async Task LoadMessageGroup(string groupN, string userID)
        {

            GroupChat gr = null;
            int groupID = 0;
            try
            {
                gr = (from getGroup in _db.GroupChats
                      where getGroup.GroupName.Equals(groupN)
                      select getGroup).Single();
                groupID = gr.GroupId;
            }
            catch (Exception ex)
            {

            }
            messageGroups = from lst in _db.MessageGroups
                            where lst.GroupId == groupID
                            select lst;
            JsonSerializerOptions options = new()
            {
                ReferenceHandler = ReferenceHandler.IgnoreCycles,
                WriteIndented = true
            };
            string jsonString = JsonSerializer.Serialize(messageGroups, options);
            Console.WriteLine("jsonnnnnnnnnnnnn " + jsonString);
            await Clients.Client(userID).SendAsync("ReceiveListMessage", jsonString);
            Console.WriteLine("get list success ");
        }

        public async Task LoadMessageUser(string username, string userID)
        {

            Account acc = null;
            int accID = 0;
            try
            {
                acc = (from getAccount in _db.Accounts
                       where getAccount.Username.Equals(username)
                       select getAccount).Single();
                accID = acc.AccountId;
            }
            catch (Exception ex)
            {

            }
            messageToUser = from lst in _db.MessageToUsers
                            where lst.UserToId == accID
                            select lst;
            JsonSerializerOptions options = new()
            {
                ReferenceHandler = ReferenceHandler.IgnoreCycles,
                WriteIndented = true
            };
            string jsonString = JsonSerializer.Serialize(messageToUser, options);
            Console.WriteLine("jsonnnnnnnnnnnnn " + jsonString);
            await Clients.Client(userID).SendAsync("ReceiveListMessageToUser", jsonString);
            Console.WriteLine("get list success ");
        }

        public async Task logOutUsername(string userID, string username)
        {

            Console.WriteLine("call logout");


            bool check = false;



            foreach (var item in listUser)
            {

                if (item.Key.Equals(userID))
                {
                    check = true;

                }
            }


            foreach (var item in listUser)
            {
                Console.WriteLine("before remove" + item.Key + " " + item.Value);
            }



            if (check == true)
            {
                listUser.Remove(userID);
                Console.WriteLine("username is: logout" + username + " userId: " + userID);
                foreach (var item in listUser)
                {
                    Console.WriteLine("after remove" + item.Key + " " + item.Value);
                }
                await Clients.Client(userID).SendAsync("logOutUser", username);



            }
            else
            {
                Console.WriteLine("cannot log out ");
            }




        }

        public async Task SendMessage(string user, string message)
        {
            if (message.Length > 0)
            {
                await Clients.All.SendAsync("ReceiveMessage", user, message);
            }

        }

        public async Task SendToUser(string user, string receiver, string message)
        {
            string userFromID = "";
            string userToID = "";
            bool checkValid = false;
            foreach (var u in listUser)
            {
                if (u.Value.Equals(user))
                {
                    userFromID = u.Key;

                }


            }
            foreach (var u in listUser)
            {
                if (u.Value.Equals(receiver))
                {
                    userToID = u.Key;

                }


            }

            foreach (var u in listUser)
            {
                if (u.Value.Equals(receiver) && u.Key.Equals(userToID))
                {
                    checkValid = true;
                }

            }
            if (message.Length <= 0)
            {
                checkValid = false;
            }
            if (checkValid == false)
            {
                return;
            }

            await Clients.Client(userToID).SendAsync("ReceiveMessage", user, message);




            MessageToUser mess = null;
            Account accFrom = null;
            Account accTo = null;
            try
            {
                accFrom = ((from accID in _db.Accounts
                            where accID.Username.Equals(user)
                            select accID)).Single();
                accTo = ((from accID in _db.Accounts
                          where accID.Username.Equals(receiver)
                          select accID)).Single();

                int accountIDFrom = accFrom.AccountId;
                int accountIDTo = accTo.AccountId;
                mess = new MessageToUser();
                mess.UserFromId = accountIDFrom;
                mess.UserToId = accountIDTo;
                mess.MessageDetails = message;
                mess.TimeSend = DateTime.Now;
                mess.UserFrom = user;
                _db.MessageToUsers.Add(mess);
                _db.SaveChanges();

            }
            catch (Exception ex)
            {
                Console.WriteLine("errrorrrrrrrrrerererererererere " + ex);
            }

        }


        public string GetConnectionId() => Context.ConnectionId;

    }
}