using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace lab3SignalR.Pages
{
    public class messageBoxModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
