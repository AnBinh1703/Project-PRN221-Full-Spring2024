create database signalRDatabase
use  signalRDatabase

create table account(
accountId int primary key identity(1,1),
username nvarchar(50) not null
)
create table groupChat(
groupId int primary key identity(1,1),
groupName nvarchar(50) not null
)
create table groupDetails(
groupDetailsID int primary key identity(1,1),
groupId int ,
groupName nvarchar(50) not null,
accountId int ,
foreign key (groupId) references groupChat(groupId),
foreign key (accountId) references account(accountId)
)

create table messageGroup(
messageGroupId int primary key identity(1,1),
groupId int ,
accountId int ,
messageDetails nvarchar(MAX),
timeSend datetime not null,
userFrom nvarchar(50) not null,
foreign key (groupId) references groupChat(groupId),
foreign key (accountId) references account(accountId)
)

create table messageToUser(
messageID int primary key identity(1,1),
userFromID int ,
userToID int,
messageDetails nvarchar(MAX),
timeSend datetime not null,
userFrom nvarchar(50) not null,
foreign key (userFromID) references account(accountId),
foreign key (userToID) references account(accountId)
)
