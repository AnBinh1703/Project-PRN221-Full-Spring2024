﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Serialization;
using Microsoft.Win32;
using Q1.Models;
using Q1.Repository;
namespace Q1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Employee> Employeess = new List<Employee>();
        IEmpRepository empRepository;
        public MainWindow(IEmpRepository repository)
        {

            InitializeComponent();
            empRepository = repository;
        }
        private void LoadEmpList()
        {
            lvEmps.ItemsSource = empRepository.GetEmployees();

        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                LoadEmpList();
                MessageBox.Show("Loaded Successfully", "Load");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Load car list");
            }
        }
        private int checkValidationInt()
        {
            try
            {
                int b = int.Parse(txtEmpId.Text);
            }
            catch (Exception ex)
            {
                return 0;
            }
            return 1;
        }

        private bool blankInput()
        {
            if (txtEmpId.Text.Length < 1 || txtEmpName.Text.Length < 1 || txtPhone.Text.Length < 1
                 || myDatePicker.Text.Length < 1) return false;
            return true;
        }
        private Employee GetEmployeeObjects()
        {
            Employee employee = null;
            try
            {
                string check = "Female";
                if (male.IsChecked == true)
                {
                    check = "Male";
                }
                employee = new Employee
                {
                    //Id = int.Parse(txtEmpId.Text),
                    Name = txtEmpName.Text,
                    Phone = txtPhone.Text,
                    Idnumber = ComboBox1.Text,
                    Dob = myDatePicker.SelectedDate,
                    Gender = check
                };

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Get Employee");
            }

            return employee;
        }

        private Employee GetEmployeeObjectsEdit()
        {
            Employee employee = null;
            try
            {
                string check = "Female";
                if (male.IsChecked == true)
                {
                    check = "Male";
                }
                employee = new Employee
                {
                    Id = int.Parse(txtEmpId.Text),
                    Name = txtEmpName.Text,
                    Phone = txtPhone.Text,
                    Idnumber = ComboBox1.Text,
                    Dob = myDatePicker.SelectedDate,
                    Gender = check
                };

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Get Employee");
            }

            return employee;
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (checkValidationInt() == 0)
                {
                    MessageBox.Show("id is interger");

                    return;
                }

                if (!blankInput())
                {
                    MessageBox.Show("Blank input", "Insert car");
                    return;
                }
                Employee employee = GetEmployeeObjects();
                empRepository.InsertEmployee(employee);
                LoadEmpList();
                MessageBox.Show($"{employee.Name} inserted successfully ", "Insert Employee");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Insert car");
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!blankInput())
                {
                    MessageBox.Show("Blank input", "Insert employee");
                    return;
                }
                Employee employee = GetEmployeeObjectsEdit();
                empRepository.UpdateEmployee(employee);
                LoadEmpList();
                MessageBox.Show($"{employee.Name} updated successfully ", "Update employee");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Update car");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!blankInput())
                {
                    MessageBox.Show("Blank input", "Insert car");
                    return;
                }
                Employee employee = GetEmployeeObjectsEdit();
                empRepository.DeleteEmployee(employee);
                LoadEmpList();
                MessageBox.Show($"{employee.Name} deleted successfully ", "Delete car");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Delete car");
            }
        }
        private void btnAddList_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (!blankInput())
                {
                    MessageBox.Show("Blank input", "Insert Employee");
                    return;
                }
                Employee employee = GetEmployeeObjectsEdit();
                Employeess.Add(employee);
                lvEmps.ItemsSource = Employeess.ToList();
                MessageBox.Show("add Emp sucess");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Delete car");
            }
        }
        private void Button_Import_Xml(object sender, RoutedEventArgs e)
        {
            

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "XML Files (*.xml)|*.xml";
            openFileDialog.Multiselect = false;

            bool? result = openFileDialog.ShowDialog();

            if (result == true)
            {
                string selectedFile = openFileDialog.FileName;

                XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Employee>));
                using (FileStream fileStream = new FileStream(openFileDialog.FileName, FileMode.Open))
                {
                    var Employees = (List<Employee>)xmlSerializer.Deserialize(fileStream);
                    lvEmps.ItemsSource = Employees;
                }
            }
        }
        private void Button_SaveToFileXml(object sender, RoutedEventArgs e)
        {
            List<abc> myList = new List<abc>();
            abc obj1 = new abc
            {
                Id = 1,
                Name = "John Doe",
                Gender = "Male",
                Dob = new DateTime(1990, 1, 1),
                Phone = "123456789",
                Idnumber = "ABC123"
            };
            myList.Add(obj1);

            // Create another instance of abc and add it to the list
            abc obj2 = new abc
            {
                Id = 2,
                Name = "Jane Smith",
                Gender = "Female",
                Dob = new DateTime(1995, 2, 2),
                Phone = "987654321",
                Idnumber = "DEF456"
            };
            myList.Add(obj2);
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.DefaultExt = "xml";
            saveFileDialog.Filter = "XML files (*.xml)|*.xml";
            if (saveFileDialog.ShowDialog() != true)
            {
                return;
            }

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<abc>));
            using (FileStream fileStream = new FileStream(saveFileDialog.FileName, FileMode.Create))
            {
                xmlSerializer.Serialize(fileStream, myList);
            }
        }
        private void btnImportFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;

            bool? result = openFileDialog.ShowDialog();
            try
            {
                List<Employee> list = ReadDataFromFile<List<Employee>>(openFileDialog.FileName);
                foreach (Employee item in list)
                {
                    Employeess.Add(item);
                }
                lvEmps.ItemsSource = Employeess.ToList();
                MessageBox.Show("Real file sucess");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Delete car");
            }
        }

        private void Button_SaveToFileJson(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.DefaultExt = "json";
            if (saveFileDialog.ShowDialog() != true)
            {
                return;
            }
            File.WriteAllText(saveFileDialog.FileName, JsonSerializer.Serialize(Employeess));
        }

        private T ReadDataFromFile<T>(string path)
        {
            string json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<T>(json);
        }

        private void btnSaveDB_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                foreach (Employee item in Employeess)
                {
                    item.Id = 0;
                    empRepository.InsertEmployee(item);
                }
                LoadEmpList();
                MessageBox.Show("Save DB success");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Delete car");
            }
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {

        }

        private void lvEmps_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Employee emp = (Employee)lvEmps.SelectedItem;
            if (emp == null)
                return;
            else
            {
                if (emp.Gender.Equals("Male"))
                {
                    male.IsChecked = true;
                }
                else
                {
                    female.IsChecked = true;
                }
            }
            ComboBox1.Text = emp.Idnumber;
            cba.IsChecked = true;
        }


    }


}
