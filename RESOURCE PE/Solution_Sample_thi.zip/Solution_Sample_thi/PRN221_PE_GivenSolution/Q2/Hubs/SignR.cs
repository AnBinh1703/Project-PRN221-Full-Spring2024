﻿using Microsoft.AspNetCore.SignalR;

namespace Q2.Hubs
{
    public class SignR : Hub
    {

    }
}
